<p align="center">
  Mac OS Classic - A Clover Theme by Machinee<br />
  (Work in progress)
</p>



![screen](/screenshots/screen.png)




<p align="center">Created a Classic Mac OS Theme for Clover Bootloader. Thought I'd share it for anyone interested.
It has the features of the Classic Mac OS with a modern look.</p>


<p align="center">Features</p>

<p align="center">
Animated Banner<br />
Scrollbar<br />
Custom Icons<br />
Custom Font<br />
</p>


![screen](/screenshots/classic_logo.gif)



![screen](/screenshots/screen_selection_small.jpg)



![screen](/screenshots/screen_font.jpg)



![screen](/screenshots/screen_scrollbar.jpg)





<p align="center">The non selected entries will turn to life with colors when selected.<br />
Smaller monitors will also have a Classic Mac OS styled scrollbar when needed.</p>




<p>
Notes:<br />
I couldn't really get the scrollbar to work exactly as intended for now, seems to be a really buggy feature.<br />
I might take requests for icons etc. if there's interest, we'll see.<br />
Designed with 2.5K monitors in mind, let me know if something doesn't look right at other resolutions.
</p>





<p align="center">Enjoy!</p>
